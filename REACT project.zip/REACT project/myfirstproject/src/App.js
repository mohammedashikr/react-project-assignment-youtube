

import Assignment1 from "./assignments/Assignment1";

function App() {
  return (
    <div >
      <Assignment1></Assignment1>
    </div>
  );
}

export default App;
